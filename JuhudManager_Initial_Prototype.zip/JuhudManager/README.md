# JuhudManager

Initial general-purpose HRM prototype using GitHub Pages + Cloudflare Workers + Cloudflare D1.

## Architecture

- `public/`: static frontend for GitHub Pages
- `worker/`: Cloudflare Worker REST API
- `worker/migrations/`: D1 SQL migrations
- D1 database binding name: `DB`
- Database name: `JuhudDB`

## Prototype scope

- Login using NRIC, passport, email, or WhatsApp
- PBKDF2 password hashing (no plaintext passwords)
- Opaque server-side sessions in D1; the prototype passes a bearer token from sessionStorage (and also sets a Secure cookie where supported)
- User and profile administration
- English / Bahasa Malaysia language switch
- Activity type management
- User activity submissions
- Supervisor/admin review
- Audit trail

## Important security and deployment notes

1. This is a starter prototype, not a production-certified HR system.
2. Do not store real NRIC/passport data until privacy, retention, access and incident-response policies are approved.
3. NRIC/passport/email/WhatsApp identifiers are encrypted at rest by the Worker and indexed using keyed HMAC hashes. Configure strong independent secrets.
4. Use a password of at least 12 characters. The original eight-character proposal is not recommended for accounts holding personal information.
5. Set `ALLOWED_ORIGIN` to the exact GitHub Pages origin. Do not use `*` with credentialed requests.
6. Configure Cloudflare secrets; never commit secrets to GitHub.
7. Bootstrap the first Super Admin once, then remove/rotate `BOOTSTRAP_SECRET`.
8. This prototype uses a single organisation. Multi-tenant separation is not included.
9. Address autocomplete is not connected to a paid/geocoding provider. Country/state/city/postcode are stored as editable text in this MVP; reference datasets can be added later.
10. Before production, add MFA, email/WhatsApp verification, password reset workflow, rate limiting/WAF rules, data export/deletion workflows, backups, monitoring, and a formal security review.

## 1. Create D1 database

From the `worker` directory:

```bash
npm install
npx wrangler d1 create JuhudDB
```

Copy the returned `database_id` into `worker/wrangler.toml`.

Apply migrations:

```bash
npx wrangler d1 migrations apply JuhudDB --remote
```

## 2. Configure Worker secrets and variables

Edit `worker/wrangler.toml` and set `ALLOWED_ORIGIN` to:

```text
https://YOUR_GITHUB_USERNAME.github.io
```

Set secrets from `worker/`:

```bash
npx wrangler secret put PASSWORD_PEPPER
npx wrangler secret put ID_LOOKUP_SECRET
npx wrangler secret put ID_ENCRYPTION_KEY
npx wrangler secret put BOOTSTRAP_SECRET
```

Generate independent random secrets. `ID_ENCRYPTION_KEY` must be a 32-byte key encoded as base64. Example generation:

```bash
openssl rand -base64 32
openssl rand -hex 32
```

Use a different random value for each secret. `PASSWORD_PEPPER`, `ID_LOOKUP_SECRET`, and `BOOTSTRAP_SECRET` should be long random strings. `ID_ENCRYPTION_KEY` must decode to exactly 32 bytes.

Deploy:

```bash
npx wrangler deploy
```

Copy the Worker URL, e.g. `https://juhudmanager-api.YOUR_SUBDOMAIN.workers.dev`.

## 3. Bootstrap first Super Admin

After deploying the Worker, run this request once (replace values):

```bash
curl -X POST "https://YOUR_WORKER_URL/api/setup/bootstrap" \
  -H "Content-Type: application/json" \
  -H "X-Bootstrap-Secret: YOUR_BOOTSTRAP_SECRET" \
  -d '{
    "fullName":"System Administrator",
    "loginType":"email",
    "loginIdentifier":"admin@example.com",
    "email":"admin@example.com",
    "password":"ChangeThis-StrongPassword-2026"
  }'
```

After successful bootstrap, rotate or remove `BOOTSTRAP_SECRET` and disable the bootstrap route in code before production.

## 4. Configure frontend

Edit `public/config.js` and set `API_BASE_URL` to your deployed Worker URL, without a trailing slash.

For example:

```js
window.JUHUD_CONFIG = {
  API_BASE_URL: "https://juhudmanager-api.YOUR_SUBDOMAIN.workers.dev"
};
```

## 5. Publish frontend on GitHub Pages

- Create a GitHub repository, e.g. `juhudmanager`.
- Upload the contents of `public/` to the repository root, or configure Pages to publish the `/public` folder from the default branch.
- In GitHub: Settings → Pages → Deploy from a branch.
- Select branch and folder.
- Ensure the resulting Pages origin matches Worker `ALLOWED_ORIGIN`.

## API endpoints

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | Public | Health check |
| POST | `/api/setup/bootstrap` | Bootstrap secret | Create first Super Admin |
| POST | `/api/auth/login` | Public | Login |
| POST | `/api/auth/logout` | Authenticated | Logout |
| GET | `/api/me` | Authenticated | Current user |
| PUT | `/api/profile` | Authenticated | Update own profile |
| GET | `/api/activities` | Authenticated | List activity types and own submissions |
| POST | `/api/activities` | Authenticated | Submit an activity |
| GET | `/api/admin/users` | Admin | List users |
| POST | `/api/admin/users` | Admin | Create user |
| GET | `/api/admin/submissions` | Admin/Supervisor | List submissions |
| PATCH | `/api/admin/submissions/:id` | Admin/Supervisor | Review submission |
| GET | `/api/admin/activity-types` | Admin | List activity types |
| POST | `/api/admin/activity-types` | Admin | Create activity type |

## Database migrations

Migrations are numbered and applied in order using Wrangler. Never edit an already-applied migration in a live environment; create a new migration instead.
